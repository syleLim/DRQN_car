from DQN_R import Agent

agent = Agent()

agent.Train()

