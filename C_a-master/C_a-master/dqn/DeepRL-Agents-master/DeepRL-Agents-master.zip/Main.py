from Agent import Agent

agent = Agent(True)

agent.Train()

